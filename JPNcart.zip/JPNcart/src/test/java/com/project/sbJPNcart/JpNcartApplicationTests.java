package com.project.sbJPNcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpNcartApplicationTests {

	@Test
	void contextLoads() {
	}

}
